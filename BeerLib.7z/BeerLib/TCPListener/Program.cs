﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Collections.Generic;
using BeerLib;
using Newtonsoft.Json;

namespace TCPListener
{
    class Program
    {
        static List<Beer> beerList = new List<Beer>
        {
            new Beer{id = 1, name = "Carlsberg", price = 1, abv = 6 },
            new Beer{id = 2, name = "Tuborg", price = 42, abv = 15 },

        };
        
        public static void AddBeer(Beer beer)
        {
            beerList.Add(beer);
        }
        public static Beer GetById(int id)
        {
            return beerList.Find(x => x.id == id);
        }
        public

        static void Main(string[] args)
        {
            IPAddress ip = IPAddress.Parse("127.0.0.1");

            TcpListener serverSocket = new TcpListener(ip, port: 7777);
            serverSocket.Start();
            Console.WriteLine(value: "Server Started");
            TcpClient connectSocket = serverSocket.AcceptTcpClient();

            Console.WriteLine(value: "Server Activated");

            Stream ns = connectSocket.GetStream();

            StreamReader sr = new StreamReader(ns);
            StreamWriter sw = new StreamWriter(ns);
            sw.AutoFlush = true;
            
            string message = sr.ReadLine();
            string answer = "";

            if (message == "GetAll")
            {
                foreach(Beer beer in beerList)
                {
                    Console.WriteLine($"ID { beer.id}: {beer.name}, Price {beer.price}, abv {beer.abv}" );
                }
            }
            else if (message == "Gem")
            {
                string jsonString = sr.ReadLine();
                Beer beer = JsonConvert.DeserializeObject<Beer>(jsonString);
                AddBeer(beer);
            }
            else if (message == "GetByID")
            {
                int id = Int32.Parse(sr.ReadLine());
                answer = GetById(id).ToString();
                Console.WriteLine(answer);
                sw.WriteLine(answer);
            }
            Console.WriteLine(value: "client: " + message);
            answer = message.ToUpper();
            sw.WriteLine(answer);
            message = sr.ReadLine();

            ns.Close();
            connectSocket.Close();
            serverSocket.Stop();
        }
    }
}
