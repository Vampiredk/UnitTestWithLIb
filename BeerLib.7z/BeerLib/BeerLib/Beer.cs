﻿using System;

namespace BeerLib
{
    public class Beer
    {
        private string _name;
        private int _id;
        private int _price;
        private int _abv;

        public string name
        {
            get => _name;
            set
            {
                if (value.Length <= 3) throw new ArgumentException();
                if (value == null) throw new ArgumentNullException();
                _name = value;
            }
        }
        public int id
        {
            get => _id;
            set
            {
                if (value <= 0) throw new ArgumentException();
                _id = value;
            }
        }
        public int price 
        {
            get => _price;
            set
            {
                if (value < 0) throw new ArgumentException();
                _price = value;
            }
        }
        public int abv
        {
            get => _abv;
            set
            {
                if (value <= 0 || value >= 100) throw new ArgumentOutOfRangeException();
                _abv = value;
            }
        }


    }
}
