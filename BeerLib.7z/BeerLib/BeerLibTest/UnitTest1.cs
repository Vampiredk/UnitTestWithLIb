using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeerLib;
using System;
using System.Collections.Generic;
using System.Text;

namespace BeerLibTest
{
    [TestClass]
    public class UnitTest1
    {
        Beer Beer1 = new Beer();
        [TestMethod]
        public void BeerNameTest()
        {
            Beer1.name = "Carl";
            Assert.ThrowsException<ArgumentException>(() => Beer1.name = "Tub");
            //Assert.ThrowsException<ArgumentNullException>(() => Beer1.name = null);
            Assert.AreEqual("Carl", Beer1.name);
        }
        [TestMethod]
        public void BeerIdTest()
        {
            Beer1.id = 42;
            Assert.ThrowsException<ArgumentException>(() => Beer1.id = -29);
            Assert.ThrowsException<ArgumentException>(() => Beer1.id = 0);
            Assert.AreEqual(42, Beer1.id);

        }
        [TestMethod]
        public void BeerPriceTest()
        {
            Beer1.price = 420;
            Assert.ThrowsException<ArgumentException>(() => Beer1.price = -20);
            Assert.AreEqual(420, Beer1.price);
        }
        [TestMethod]
        public void BeerABVTest()
        {
            Beer1.abv = 27;
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => Beer1.abv = -27);
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => Beer1.abv = 127);
            Assert.AreEqual(27, Beer1.abv);
        }

    }
}
